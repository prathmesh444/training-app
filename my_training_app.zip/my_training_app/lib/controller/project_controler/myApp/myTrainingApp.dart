
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_training_app/controller/screen_controller/home_controller.dart';


import '../route/route_navigation.dart';

class MyTrainingApp extends StatefulWidget {
  const MyTrainingApp({super.key});

  @override
  State<MyTrainingApp> createState() => _MyTrainingAppState();
}

class _MyTrainingAppState extends State<MyTrainingApp> {

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }


  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      initialRoute: RouteNavigation.homeScreenRoute,
      debugShowCheckedModeBanner: false,
      onGenerateRoute: RouteNavigation.generateRoute,
      darkTheme: ThemeData(brightness: Brightness.dark,),
      theme: ThemeData(brightness: Brightness.light),
      themeMode: ThemeMode.light,
      initialBinding: BindingsBuilder.put(() {
        HomeController ctrl = HomeController();
        ctrl.init();
        return ctrl;
      }),
    );
  }
}