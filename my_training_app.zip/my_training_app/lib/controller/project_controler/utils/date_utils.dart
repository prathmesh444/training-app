import 'package:intl/intl.dart';

extension CustomDateUtils on DateTime {

  /// Converts dateTime in format d MMM , example: "30 Oct".
  static String getDateMonth(DateTime date) {
    return DateFormat("d MMM").format(date);
  }

  /// Converts dateTime in format d MMM, yyyy , example: "Oct 30 - Oct 31, 2021".
  static String getRangedMonthDateYear(DateTime startDate, DateTime endDate) {
    return "${DateFormat("MMM d").format(startDate)} - ${DateFormat("MMM d").format(endDate)}, ${DateFormat("yyyy").format(startDate)}";
  }

  /// Converts dateTime in format hh:mm a, example: "10:00 am - 11:00 am".
  static getRangedTime(DateTime startTime, DateTime endTime) {
    return "${DateFormat("hh:mm a").format(startTime)} - ${DateFormat("hh:mm a").format(endTime)}";
  }

}