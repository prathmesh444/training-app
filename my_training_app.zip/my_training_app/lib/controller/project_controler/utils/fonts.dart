class FontFamily{
  static const String poppins = "Poppins";
}