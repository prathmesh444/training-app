import 'package:flutter/material.dart';
import 'package:my_training_app/view/home/home_screen.dart';
import 'package:my_training_app/view/training_details/training_details_screen.dart';
import 'package:page_transition/page_transition.dart';

class RouteNavigation {
  static const String homeScreenRoute = '/home';
  static const String trainingDetailsScreenRoute = '/trainingDetails';

  static Route<dynamic>? generateRoute(RouteSettings settings) {
    switch (settings.name) {

      case homeScreenRoute:
        return _customFadeRoute(child: const HomeScreen());


        case trainingDetailsScreenRoute:
          var args = settings.arguments as TrainingDetailsScreen;
          return _customFadeRoute(child: TrainingDetailsScreen(training: args.training));

      default: return _customFadeRoute(child: const HomeScreen(),);

    }
  }

  static PageTransition _customFadeRoute({required child}){
    return PageTransition(
      type: PageTransitionType.fade,
      duration: const Duration(milliseconds: 500),
      child: child,
    );
  }

}
