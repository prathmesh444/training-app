import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:my_training_app/data/models/training.dart';
import 'package:my_training_app/data/repository/training_repo.dart';
import 'package:my_training_app/view/helper/logging/print_log.dart';
import 'package:my_training_app/view/helper/sheets/bottom_sheets.dart';

class HomeController extends GetxController {

  List<Training> trainingsList = [];
  List<Training> filteredtrainingsList = [];
  int selectedFilterIndex = 1;
  List<Map<String,bool>> filtersData = [];
  int totalLocationFilter = 0;
  int totalTrainingFilters = 0;
  int totalTrainerFilters = 0;
  bool isFilterUpdated = false;

   init() {
    trainingsList =  TrainingRepo.getTrainings();
    filteredtrainingsList = trainingsList;
    filtersData = [{} , {} , {} , {}];
    filtersData[0] = {};
    for (var training in trainingsList) {
      filtersData[1][training.location] = false;
      filtersData[2][training.name] = false;
      filtersData[3][training.trainerName] = false;
    }
  }

  void updateSelectedFilterIndex(int index) {
    selectedFilterIndex = index;
    update();
    PrintLog.printLog("selectedFilterIndex is $selectedFilterIndex");
  }

  void markFilter(String value) {
    filtersData[selectedFilterIndex][value] = true;
    updateFilterApplied(filtedAdded: true);
    update();
  }

  unmarkFilter(String value) {
    filtersData[selectedFilterIndex][value] = false;
    updateFilterApplied(filtedAdded: false);
    update();
  }

  onTapFiltersButton(BuildContext context) async {
     await BottomSheets.showFilterSheet(context);
     if(isFilterUpdated) {
       _applyFilters();
       isFilterUpdated = false;
        update();
     }
  }

  _applyFilters(){
    filteredtrainingsList = trainingsList.where((training) {

       return (totalLocationFilter == 0 || filtersData[1][training.location] == true)
          && (totalTrainingFilters == 0 || filtersData[2][training.name] == true)
          && (totalTrainerFilters == 0 || filtersData[3][training.trainerName] == true);

    }).toList();
    PrintLog.printLog("filteredtrainingsList is $filteredtrainingsList");
    update();
  }

  void updateFilterApplied({required bool filtedAdded}) {
    switch(selectedFilterIndex){
      case 1 : filtedAdded ? totalLocationFilter++ : totalLocationFilter--; break;
      case 2 : filtedAdded ? totalTrainingFilters++ : totalTrainingFilters--; break;
      case 3 : filtedAdded ? totalTrainerFilters++ : totalTrainerFilters--; break;
    }

    PrintLog.printLog("totalLocationFilter is $totalLocationFilter");
    PrintLog.printLog("totalTrainingFilters is $totalTrainingFilters");
    PrintLog.printLog("totalTrainerFilters is $totalTrainerFilters");
  }


}