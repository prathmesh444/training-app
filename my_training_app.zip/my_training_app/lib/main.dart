import 'package:flutter/material.dart';
import 'package:my_training_app/controller/project_controler/myApp/myTrainingApp.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyTrainingApp());
}
