
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:my_training_app/view/helper/colors/app_colors.dart';
import 'package:my_training_app/view/helper/sizing/dimensions.dart';
import 'package:my_training_app/view/helper/sizing/font_styles.dart';
import 'package:my_training_app/view/helper/widgets/text.dart';

class BtnCustom extends StatelessWidget {
  const BtnCustom({
    super.key,
    this.btnColor,
    this.titleSize,
    this.titleColor,
    this.width,
    this.height,
    this.borderRadius,
    this.border,
    this.boxShadow,
    this.linearGradient,
    this.titleWidget,
    this.title,
    required this.onPress
  });

  final Color? btnColor;
  final Dimensions? titleSize;
  final Color? titleColor;
  final double? width;
  final double? height;
  final double? borderRadius;
  final BoxBorder? border;
  final BoxShadow? boxShadow;
  final LinearGradient? linearGradient;
  final Widget? titleWidget;
  final String? title;
  final VoidCallback onPress;

  @override
  Widget build(BuildContext context) {
    return  GestureDetector(
      behavior: HitTestBehavior.translucent,
      onTap: () {
        HapticFeedback.heavyImpact();
        onPress();
      },
      child: AnimatedContainer(
        curve: Curves.linearToEaseOut,
        duration: const Duration(milliseconds: 50),
        alignment: Alignment.center,
        width: width ?? Get.width * 0.95,
        height: height ?? 50.0,
        decoration: BoxDecoration(
            borderRadius: BorderRadius.all(Radius.circular(borderRadius ?? 2.0)),
            color: btnColor ?? AppColors.primaryColor,
            border: border,

        ),
        // margin: EdgeInsets.all(25),
        child: titleWidget
            ?? BuildText(
              text: title ?? "",
              style: CustomTextStyle.defaultPoppinsStyle(
                  size: titleSize ?? Dimensions.fontSize_16sp,
                  color: titleColor ?? AppColors.whiteColor,
                weight: FontWeight.w600
              ),)
      ),
    );
  }
}
