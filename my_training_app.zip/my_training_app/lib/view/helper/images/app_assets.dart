class AppAssets{

  static const String trainingImg1 = 'assets/images/training_img_1.jpg';
  static const String trainingImg2 = 'assets/images/training_img_2.jpg';
  static const String trainingImg3 = 'assets/images/training_img_3.jpg';
  static const String trainingImg4 = 'assets/images/training_img_4.jpg';
  static const String trainingImg5 = 'assets/images/training_img_5.jpg';
  static const String trainingImg6 = 'assets/images/training_img_6.jpg';
  static const String trainingImg7 = 'assets/images/training_img_7.jpg';


  static const String trainerImg1 = 'assets/images/trainer_img_1.jpg';
  static const String trainerImg2 = 'assets/images/trainer_img_2.jpg';
  static const String trainerImg3 = 'assets/images/trainer_img_3.jpg';
  static const String trainerImg4 = 'assets/images/trainer_img_4.jpg';
  static const String trainerImg5 = 'assets/images/trainer_img_5.jpg';
  static const String trainerImg6 = 'assets/images/trainer_img_6.jpg';
  static const String trainerImg7 = 'assets/images/trainer_img_7.jpg';
  static const String trainerImg8 = 'assets/images/trainer_img_8.jpg';
  static const String trainerImg9 = 'assets/images/trainer_img_9.jpg';
  static const String trainerImg10 = 'assets/images/trainer_img_10.jpg';

  static const String universityLogo = 'assets/images/university_logo.jpg';

}