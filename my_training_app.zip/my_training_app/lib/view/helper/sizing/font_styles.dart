
import 'package:flutter/material.dart';
import 'package:my_training_app/view/helper/sizing/dimensions.dart';

import '../colors/app_colors.dart';

class CustomTextStyle {
  static TextStyle defaultPoppinsStyle({
    Dimensions? size,
    FontWeight? weight,
    Color? color,
    double? height,
    TextDecoration? textDecoration,
    double? letterSpacing,
    double? textDecorationThickness,
    Color? textDecorationColor,
    TextDecorationStyle? textDecorationStyle,
  }) {
    return TextStyle(
      // fontFamily: FontFamily.poppins,
      fontSize: size?.value ?? 14.00,
      fontWeight: weight ?? FontWeight.w400,
      height: height,
      color: color ?? AppColors.blackColor,
      decoration: textDecoration,
      letterSpacing: letterSpacing,
      decorationColor: textDecorationColor,
      decorationStyle: textDecorationStyle,
      decorationThickness: textDecorationThickness,
    );
  }
}