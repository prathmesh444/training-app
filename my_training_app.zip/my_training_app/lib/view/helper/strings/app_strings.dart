class AppString{
  static const String kViewDetails = "View Details";
  static const String kTrainings = "Trainings";
  static const String kHighlights = "Highlights";
  static const String kFilter = "Filter";
  static const String kEnroll = "Enroll Now";
  static const String kSortAndFilter = "Sort and Filter";

}