import 'package:flutter/material.dart';
import 'package:my_training_app/view/filter/filter_screen.dart';

class BottomSheets {
  static Future<void> showFilterSheet(BuildContext context) async {
    return await showModalBottomSheet(
      context: context,
      barrierColor: Colors.black.withOpacity(0.8),
      builder: (BuildContext context) {
        return const FilterScreen();
      },
    );
  }
}