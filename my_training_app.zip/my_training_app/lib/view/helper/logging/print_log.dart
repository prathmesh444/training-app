

class PrintLog{
  static void printLog(String message){
    // if(kDebugMode){
    //   log(message);
    // }
    print(message);
  }
}