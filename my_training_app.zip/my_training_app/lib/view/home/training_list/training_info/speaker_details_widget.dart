import 'package:flutter/material.dart';
import 'package:badges/badges.dart' as badge;
import 'package:get/get.dart';
import 'package:my_training_app/data/models/training.dart';
import 'package:my_training_app/view/helper/sizing/dimensions.dart';
import 'package:my_training_app/view/helper/images/app_assets.dart';
import 'package:my_training_app/view/helper/sizing/sized_box_extension.dart';
import 'package:my_training_app/view/helper/widgets/text.dart';


class SpeakerDetails extends StatelessWidget {
  const SpeakerDetails({super.key, required this.training});

  final Training training;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        badge.Badge(
          badgeStyle: const badge.BadgeStyle(badgeColor: Colors.transparent,),
          position: badge.BadgePosition.bottomEnd(),
          badgeContent: CircleAvatar(
            radius: Get.height * 0.012,
            backgroundImage: const AssetImage(AppAssets.universityLogo),
          ),
          child: CircleAvatar(
            radius: Get.height * 0.028,
            backgroundImage: AssetImage(training.trainerImage),
          ),
        ),
        PercentSizedBox.width(0.04),
        Flexible(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              BuildText(
                text: training.trainerDesignation,
                size: Dimensions.fontSize_12sp,
                weight: FontWeight.w700,
              ),
              PercentSizedBox.height(0.005),
              BuildText(
                text: training.trainerName,
                size: Dimensions.fontSize_10sp,
              ),

            ],
          ),
        ),
      ],
    );
  }
}