import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_training_app/data/models/training.dart';
import 'package:my_training_app/view/helper/colors/app_colors.dart';
import 'package:my_training_app/view/helper/sizing/dimensions.dart';
import 'package:my_training_app/view/helper/sizing/sized_box_extension.dart';
import 'package:my_training_app/view/helper/strings/app_strings.dart';
import 'package:my_training_app/view/helper/widgets/button.dart';
import 'package:my_training_app/view/helper/widgets/text.dart';

import 'speaker_details_widget.dart';

class TrainingInfo extends StatelessWidget {
  const TrainingInfo({super.key, required this.training});

  final Training training;

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          BuildText(
            text: training.tagLine,
            color: AppColors.primaryColor,
            weight: FontWeight.w700,
            size: Dimensions.fontSize_10sp,
          ),
          PercentSizedBox.height(0.001),
          BuildText(
            text: "${training.name} (${training.rating})",
            weight: FontWeight.w700,
            size: Dimensions.fontSize_16sp,
          ),
          PercentSizedBox.height(0.02),
          SpeakerDetails(training: training),
          PercentSizedBox.height(0.05),
        ],
      ),
        Align(
          alignment: Alignment.bottomRight,
          child: BtnCustom(
            height: 30,
            width: Get.width * 0.2,
            onPress: () {},
            title: AppString.kEnroll,
            titleColor: AppColors.whiteColor,
            titleSize: Dimensions.fontSize_12sp,
          ),
        )
      ],
    );
  }
}

