import 'package:dotted_line/dotted_line.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_training_app/controller/project_controler/route/route_navigation.dart';
import 'package:my_training_app/data/models/training.dart';
import 'package:my_training_app/view/helper/colors/app_colors.dart';
import 'package:my_training_app/view/helper/sizing/dimensions.dart';
import 'package:my_training_app/view/helper/sizing/padding_values.dart';
import 'package:my_training_app/view/helper/sizing/sized_box_extension.dart';
import 'package:my_training_app/view/helper/widgets/text.dart';
import 'package:my_training_app/view/home/training_list/training_info/training_info_widget.dart';

import 'time_info/time_info_widget.dart';

class TrainingListItem extends StatelessWidget {
  const TrainingListItem({super.key, required this.training});

  final Training training;

  @override
  Widget build(BuildContext context) {

    return Container(
      constraints: BoxConstraints(
        maxHeight: Get.height * 0.24,
        maxWidth: Get.width,
      ),
      padding: PaddingValues.symmetric(
          horizontal: Dimensions.pad_12dp,
          vertical: Dimensions.pad_12dp
      ),
      margin: PaddingValues.symmetric(
          horizontal: Dimensions.pad_12dp,
          vertical: Dimensions.pad_12dp
      ),
      decoration: BoxDecoration(
        color: AppColors.whiteColor,
        borderRadius: BorderRadius.circular(8),
        boxShadow: [
          BoxShadow(
            color: AppColors.greyColor.withOpacity(0.5),
            blurRadius: 5,
            spreadRadius: 1,
            offset: const Offset(0, 2),
          )
        ],
      ),
      child: Row(
        children: [
          // BuildText(text: training.name),
          Flexible(
            flex: 2,
              fit: FlexFit.tight,
              child:
              TimeInfo(training: training),
          ),
          PercentSizedBox.width(0.02),
          const DottedLine(
            direction: Axis.vertical,
            dashColor: AppColors.greyColor,
            dashGapLength: 4,
          ),
          PercentSizedBox.width(0.02),
          Flexible(
            flex: 4,
              fit: FlexFit.tight,
              child:
              TrainingInfo(training: training)
          ),
        ],
      )
      // child: BuildText(text: training.name),
    );
  }
}
