import 'package:flutter/material.dart';
import 'package:my_training_app/controller/project_controler/utils/date_utils.dart';
import 'package:my_training_app/data/models/training.dart';
import 'package:my_training_app/view/helper/sizing/dimensions.dart';
import 'package:my_training_app/view/helper/sizing/padding_values.dart';
import 'package:my_training_app/view/helper/sizing/sized_box_extension.dart';
import 'package:my_training_app/view/helper/widgets/text.dart';

class TimeInfo extends StatelessWidget {
  const TimeInfo({super.key, required this.training});
  final Training training;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding:  PaddingValues.symmetric(vertical: Dimensions.pad_16dp),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          BuildText(
            text: CustomDateUtils.getRangedMonthDateYear(training.startDate, training.endDate),
            weight: FontWeight.w700,
            size: Dimensions.fontSize_16sp,
          ),
          PercentSizedBox.height(0.01),
          BuildText(
            text: CustomDateUtils.getRangedTime(training.startTime, training.endTime),
            size: Dimensions.fontSize_10sp,
          ),
          const Spacer(),
          BuildText(
            text: training.location,
            size: Dimensions.fontSize_12sp,
            weight: FontWeight.w500,
          )
        ],
      ),
    );
  }
}
