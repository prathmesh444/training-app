import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_training_app/controller/screen_controller/home_controller.dart';
import 'package:my_training_app/view/helper/widgets/text.dart';
import 'package:my_training_app/view/home/highlights/training_highlights_widget.dart';
import 'package:my_training_app/view/home/training_list/training_list_item_widget.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {

  HomeController homeCtrl = Get.find();

  @override
  initState(){
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder(
      init: homeCtrl,
      builder: (ctrl) {
        return SafeArea(
          child: Scaffold(
            body: SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  TrainingHighlights(),
                  if(homeCtrl.filteredtrainingsList.isEmpty)
                  const Center(child: BuildText(text: "No trainings found")),

                  ...homeCtrl.filteredtrainingsList.map((training) => TrainingListItem(training: training)),
                ],
              ),
            )
          ),
        );
      }
    );
  }
}
