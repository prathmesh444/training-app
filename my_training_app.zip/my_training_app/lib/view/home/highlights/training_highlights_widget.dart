import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_training_app/controller/screen_controller/home_controller.dart';
import 'package:my_training_app/view/helper/colors/app_colors.dart';
import 'package:my_training_app/view/helper/sizing/dimensions.dart';
import 'package:my_training_app/view/helper/sizing/padding_values.dart';
import 'package:my_training_app/view/helper/sizing/sized_box_extension.dart';
import 'package:my_training_app/view/helper/strings/app_strings.dart';
import 'package:my_training_app/view/helper/widgets/text.dart';
import 'package:my_training_app/view/home/highlights/carousel_widget.dart';

class TrainingHighlights extends StatefulWidget {
  const TrainingHighlights({super.key});

  @override
  State<TrainingHighlights> createState() => _TrainingHighlightsState();
}

class _TrainingHighlightsState extends State<TrainingHighlights> {

  final HomeController ctrl = Get.find();

  @override
  Widget build(BuildContext context) {
    return GetBuilder(
      init: ctrl,
      builder: (ctrl) {
        return Stack(
          children: [
            /// Background Details with Filter
            Column(

              children: [
                /// red container
                Container(
                  height: Get.height * 0.25,
                  padding: PaddingValues.all(Dimensions.pad_12dp),
                  width: double.infinity,
                  color: AppColors.primaryColor,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      /// Trainings heading
                      const Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          BuildText(
                              text: AppString.kTrainings,
                              color: AppColors.whiteColor,
                              size: Dimensions.fontSize_28sp,
                              weight: FontWeight.w700
                          ),
                          Icon(Icons.menu, color: AppColors.whiteColor, size: 20,)
                        ],
                      ),

                      PercentSizedBox.height(0.04),

                      /// Highlights heading
                      const BuildText(
                          text: AppString.kHighlights,
                          color: AppColors.whiteColor,
                          size: Dimensions.fontSize_20sp,
                          weight: FontWeight.w500
                      ),

                    ],
                  ),
                ),

                /// white container with Filter
                Container(
                  height: Get.height * 0.17,
                  width: Get.width,
                  padding: PaddingValues.all(Dimensions.pad_16dp),
                  decoration: BoxDecoration(
                    color: AppColors.whiteColor,
                    boxShadow: [
                      BoxShadow(
                        color: AppColors.blackColor.withOpacity(0.1),
                        spreadRadius: 0,
                        blurRadius: 2,
                        offset: const Offset(0, 1), // changes position of shadow
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      /// Filter
                      GestureDetector(
                        behavior: HitTestBehavior.translucent,
                        onTap: () => ctrl.onTapFiltersButton(context),
                        child: Container(
                          width: Get.width * 0.16,
                          height: Get.height * 0.033,
                          padding: PaddingValues.all(Dimensions.pad_2dp),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(4),
                            border: Border.all(color: AppColors.greyColor)
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Icon(Icons.tune, color: AppColors.greyColor, size: 12,),
                              PercentSizedBox.width(0.005),
                              const BuildText(
                                  text: AppString.kFilter,
                                  color: AppColors.greyColor,

                              )
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),

            /// Carousel
            Positioned(
              top: Get.height * 0.16,
              left: 0,
              child: SizedBox(
                width: Get.width,
                  child: HighlightCarousel(highlights: ctrl.trainingsList.sublist(0, 4))
              )
            ),
          ],
        );
      }
    );
  }
}




