import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_training_app/data/models/training.dart';
import 'package:my_training_app/view/helper/colors/app_colors.dart';
import 'package:my_training_app/view/helper/sizing/dimensions.dart';
import 'package:my_training_app/view/helper/sizing/padding_values.dart';
import 'package:my_training_app/view/helper/sizing/sized_box_extension.dart';
import 'package:my_training_app/view/home/highlights/carousel_item_widget.dart';


class HighlightCarousel extends StatefulWidget {
  const HighlightCarousel({super.key, required this.highlights});
  final List<Training> highlights;

  @override
  State<HighlightCarousel> createState() => _HighlightCarouselState();
}

class _HighlightCarouselState extends State<HighlightCarousel> {

  final CarouselSliderController carouselController = CarouselSliderController();
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [

        /// MOVE LEFT
        GestureDetector(
          onTap: () => carouselController.previousPage(),
          child: Container(
            decoration: BoxDecoration(
                color: AppColors.blackColor.withOpacity(0.3),
                borderRadius: BorderRadius.circular(2)
            ),
            padding: PaddingValues.symmetric(horizontal: Dimensions.pad_4dp, vertical: Dimensions.pad_24dp),
            child: const Icon(Icons.arrow_back_ios, size: 14, color: AppColors.whiteColor,),
          ),
        ),

        PercentSizedBox.width(.01),

        ConstrainedBox(
          constraints: BoxConstraints(maxHeight: Get.height * 0.18, maxWidth: Get.width * 0.8),
          child: CarouselSlider.builder(
            carouselController: carouselController,
            options: CarouselOptions(
              height: Get.height * 0.18,
              viewportFraction: 1,
              enableInfiniteScroll: true,
              initialPage: 0,
              reverse: false,
              autoPlay: true,
              autoPlayInterval: const Duration(seconds: 2),
              autoPlayAnimationDuration: const Duration(milliseconds: 800),
              autoPlayCurve: Curves.fastOutSlowIn,
              enlargeCenterPage: true,
              scrollDirection: Axis.horizontal,
              onPageChanged: (index, reason) {
                // carouselController.animateToPage(index);
              },
            ),
            itemCount: widget.highlights.length,
            itemBuilder: (context, index, realIndex) {
              return CarouselItem(training: widget.highlights[index]);
            },
          ),
        ),

        PercentSizedBox.width(.01),

        /// MOVE RIGHT
        GestureDetector(
          onTap: () => carouselController.nextPage(),
          child: Container(
            decoration: BoxDecoration(
                color: AppColors.blackColor.withOpacity(0.3),
                borderRadius: BorderRadius.circular(2)
            ),
            padding: PaddingValues.symmetric(horizontal: Dimensions.pad_4dp, vertical: Dimensions.pad_24dp),
            child: const Icon(Icons.arrow_forward_ios, size: 14, color: AppColors.whiteColor,),
          ),
        ),
      ],
    );
  }
}
