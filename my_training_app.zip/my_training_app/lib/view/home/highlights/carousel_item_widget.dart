
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_training_app/controller/project_controler/route/route_navigation.dart';
import 'package:my_training_app/controller/project_controler/utils/date_utils.dart';
import 'package:my_training_app/data/models/training.dart';
import 'package:my_training_app/view/helper/colors/app_colors.dart';
import 'package:my_training_app/view/helper/sizing/dimensions.dart';
import 'package:my_training_app/view/helper/sizing/font_styles.dart';
import 'package:my_training_app/view/helper/sizing/padding_values.dart';
import 'package:my_training_app/view/helper/sizing/sized_box_extension.dart';
import 'package:my_training_app/view/helper/strings/app_strings.dart';
import 'package:my_training_app/view/helper/widgets/text.dart';
import 'package:my_training_app/view/training_details/training_details_screen.dart';

class CarouselItem extends StatelessWidget {
  const CarouselItem({super.key, required this.training});
  final Training training;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.translucent,
      onTap: () {
        Get.toNamed(RouteNavigation.trainingDetailsScreenRoute, arguments: TrainingDetailsScreen(training: training));
      },
      child: Container(
        padding: PaddingValues.all(Dimensions.pad_8dp),

        decoration: BoxDecoration(
          color: AppColors.whiteColor,
          backgroundBlendMode: BlendMode.darken,
          image:  DecorationImage(
            colorFilter: ColorFilter.mode(AppColors.blackColor.withOpacity(0.7), BlendMode.darken),
            image: AssetImage(training.trainingImage),
            fit: BoxFit.cover,
          ),
          borderRadius: BorderRadius.circular(4),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.5),
              spreadRadius: 5,
              blurRadius: 7,
              offset: const Offset(0, 3), // changes position of shadow
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.end,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            /// Title
            BuildText(
              text: training.name,
              style: CustomTextStyle.defaultPoppinsStyle(
                color: AppColors.whiteColor,
                weight: FontWeight.w700,
                size: Dimensions.fontSize_14sp,
              ),
            ),

            PercentSizedBox.height(0.002),

            /// Location and Date
            BuildText(
              text: '${training.location} | ${CustomDateUtils.getDateMonth(training.startDate)} - ${CustomDateUtils.getDateMonth(training.endDate)}',
              size: Dimensions.fontSize_12sp,
              color: AppColors.whiteColor,
            ),

            PercentSizedBox.height(0.01),

            /// Price Details
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text.rich(
                  TextSpan(
                    text: "\$${training.actualPrice.toString()}",
                    style: CustomTextStyle.defaultPoppinsStyle(
                      textDecoration: TextDecoration.lineThrough,
                      textDecorationColor: AppColors.primaryColor,
                      textDecorationThickness: 2,
                      color: AppColors.primaryColor.withOpacity(0.8),
                      size: Dimensions.fontSize_12sp,
                      weight: FontWeight.w500,
                    ),
                    children: [
                      TextSpan(
                          text: "  \$${training.discountedPrice.toString()}",
                          style: CustomTextStyle.defaultPoppinsStyle(
                            textDecoration: TextDecoration.none,
                            color: AppColors.primaryColor,
                            weight: FontWeight.w700,
                            size: Dimensions.fontSize_16sp
                          )
                      ),
                    ],
                  ),


                ),

                RichText(
                  text: TextSpan(
                    text: "${AppString.kViewDetails} ",
                    style: CustomTextStyle.defaultPoppinsStyle(
                      color: AppColors.whiteColor,
                      size: Dimensions.fontSize_10sp,
                    ),
                    children: const [
                      WidgetSpan(
                        alignment: PlaceholderAlignment.middle,
                        child: Icon(
                          Icons.arrow_forward,
                          size: 10,
                          color: AppColors.whiteColor,
                        ),
                      )
                    ]
                  ),
                )
              ],
            )
          ],
        ),
      ),
    );
  }
}
