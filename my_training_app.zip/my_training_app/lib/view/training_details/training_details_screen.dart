import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_training_app/view/helper/colors/app_colors.dart';
import 'package:my_training_app/view/helper/sizing/dimensions.dart';
import 'package:my_training_app/view/helper/sizing/padding_values.dart';
import 'package:my_training_app/view/helper/sizing/sized_box_extension.dart';
import 'package:my_training_app/view/helper/strings/app_strings.dart';
import 'package:my_training_app/view/helper/widgets/button.dart';
import 'package:my_training_app/view/helper/widgets/text.dart';

import '../../data/models/training.dart';

class TrainingDetailsScreen extends StatelessWidget {
  final Training training;
  const TrainingDetailsScreen({super.key, required this.training});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        floatingActionButton: Padding(
          padding:  PaddingValues.all(Dimensions.pad_8dp),
          child: BtnCustom(
            onPress: () {},
            borderRadius: 16,
            title: AppString.kEnroll,
            titleColor: AppColors.whiteColor,
            titleSize: Dimensions.fontSize_16sp,
          ),
        ),
        floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
        body: Stack(
          children: [
            SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  /// Top image with tagline
                  Stack(
                    children: [
                      Image.asset(
                        training.trainingImage,
                        height: 200,
                        width: double.infinity,
                        fit: BoxFit.cover,
                      ),
                      Positioned(
                        bottom: 10,
                        left: 10,
                        child: Container(
                          padding: PaddingValues.symmetric(horizontal: Dimensions.pad_12dp, vertical: Dimensions.pad_8dp),
                          decoration: BoxDecoration(
                            color: AppColors.purpleColor.withOpacity(0.8),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: BuildText(
                            text: training.tagLine,
                            color: AppColors.whiteColor,
                            size: Dimensions.fontSize_14sp,
                            weight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),

                  /// Title and Rating
                  Padding(
                    padding:  PaddingValues.all(Dimensions.pad_16dp),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Expanded(
                          child: BuildText(
                            text:training.name,
                            size: Dimensions.fontSize_24sp,
                              weight: FontWeight.bold,
                              color: AppColors.primaryColor,
                          ),
                        ),
                        Row(
                          children: [
                            const Icon(Icons.star, color: AppColors.yellowColor, size: 20),
                            PercentSizedBox.width(0.01),
                            BuildText(
                              text: training.rating.toString(),
                              size: Dimensions.fontSize_16sp, weight: FontWeight.bold
                            )
                          ],
                        ),
                      ],
                    ),
                  ),

                  /// Trainer Information
                  Padding(
                    padding:  PaddingValues.symmetric(horizontal: Dimensions.pad_16dp),
                    child: Row(
                      children: [
                        CircleAvatar(
                          backgroundImage: AssetImage(training.trainerImage),
                          radius: 30,
                        ),
                        PercentSizedBox.width(0.1),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            BuildText(
                              text: training.trainerName,
                              size: Dimensions.fontSize_18sp, weight: FontWeight.bold),
                            BuildText(
                              text: training.trainerDesignation,
                              size: Dimensions.fontSize_14sp, color: AppColors.greyColor),
                          ],
                        ),
                      ],
                    ),
                  ),

                  PercentSizedBox.height(0.02),

                  /// Location, Price, and Duration
                  Padding(
                    padding:  PaddingValues.symmetric(horizontal: Dimensions.pad_16dp),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        _buildInfoColumn(Icons.location_on, training.location, AppColors.blueColor),
                        _buildInfoColumn(
                            Icons.access_time, "${training.duration} mins", AppColors.greenColor),
                        _buildInfoColumn(
                            Icons.attach_money,
                            "\$${training.discountedPrice} (Save \$${training.actualPrice - training.discountedPrice})",
                            AppColors.primaryColor),
                      ],
                    ),
                  ),

                  PercentSizedBox.height(.05),

                  /// Summary
                  Padding(
                    padding:  PaddingValues.symmetric(horizontal: Dimensions.pad_16dp ),
                    child: const BuildText(
                      text: "Summary",
                      size: Dimensions.fontSize_20sp, weight: FontWeight.bold),

                  ),
                  Padding(
                    padding:  PaddingValues.all(Dimensions.pad_16dp),
                    child: BuildText(
                      text: training.trainingSummary,
                      size: Dimensions.pad_16dp, color: AppColors.greyColor),

                  ),

                  PercentSizedBox.height(.02),
                ],
              ),
            ),
            Positioned(
              top: 5,
              left: 5,
              child: GestureDetector(
                behavior: HitTestBehavior.translucent,
                onTap: () => Get.back(),
                child: Container(
                  alignment: Alignment.center,
                  padding: PaddingValues.all(Dimensions.pad_8dp),
                    decoration: BoxDecoration(
                        color: AppColors.whiteColor,
                        borderRadius: BorderRadius.circular(24)
                    ),
                    child: const Icon(Icons.arrow_back, color: AppColors.blackColor)),
            )
            )
          ],
        ),
      ),
    );
  }

  Widget _buildInfoColumn(IconData icon, String label, Color color) {
    return Column(
      children: [
        Icon(icon, color: color, size: 30),
        PercentSizedBox.height(0.01),
        BuildText(
          text: label,
          textAlign: TextAlign.center,
          size: Dimensions.fontSize_14sp, weight: FontWeight.bold),
      ],
    );
  }
}
