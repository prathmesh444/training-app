import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_training_app/controller/screen_controller/home_controller.dart';
import 'package:my_training_app/view/filter/filter_check_list.dart';
import 'package:my_training_app/view/helper/colors/app_colors.dart';
import 'package:my_training_app/view/helper/sizing/dimensions.dart';
import 'package:my_training_app/view/helper/sizing/padding_values.dart';
import 'package:my_training_app/view/helper/strings/app_strings.dart';
import 'package:my_training_app/view/helper/widgets/text.dart';

class FilterScreen extends StatefulWidget {
  const FilterScreen({super.key});

  @override
  State<FilterScreen> createState() => _FilterScreenState();
}

class _FilterScreenState extends State<FilterScreen> {

  HomeController homeCtrl = Get.find();
  final List<String> filterOptions = [
    "Sort by",
    "Location",
    "Training Name",
    "Trainer",
  ];

  @override
  Widget build(BuildContext context) {
    return GetBuilder(
      init: homeCtrl,
      builder: (ctrl) {
        return Container(
          height: Get.height * 0.8,
          padding: PaddingValues.all(Dimensions.pad_2dp),
          decoration: const BoxDecoration(
            color: AppColors.whiteColor,
          ),
          child: Scaffold(
            appBar: AppBar(
              automaticallyImplyLeading: false,
              title:  Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const BuildText(
                    text: AppString.kSortAndFilter,
                    color: AppColors.blackColor,
                    size: Dimensions.fontSize_20sp,
                    weight: FontWeight.w600,
                  ),
                  GestureDetector(
                    behavior: HitTestBehavior.translucent,
                    onTap: () => Get.back(),
                      child: const Icon(Icons.clear, size: 24)
                  )
                ],
              ),
            ),
            body: Row(
              children: [
                Flexible(
                  flex: 2,
                  child: ListView.builder(
                    itemCount: 4,
                    itemBuilder: (context, index) {
                      return GestureDetector(
                        behavior: HitTestBehavior.translucent,
                        onTap: () => homeCtrl.updateSelectedFilterIndex(index),
                        child: Container(
                          decoration: BoxDecoration(
                            color: homeCtrl.selectedFilterIndex == index
                                ? AppColors.whiteColor : AppColors.greyColor.withOpacity(0.2),
                            border: homeCtrl.selectedFilterIndex == index
                                ? const Border(left: BorderSide(color: AppColors.primaryColor, width: 5.0))
                                : null
                          ),
                          padding: PaddingValues.symmetric(horizontal: Dimensions.pad_8dp, vertical: Dimensions.pad_16dp),
                          child: BuildText(
                            text: filterOptions[index],
                            color: AppColors.blackColor,
                            size: Dimensions.fontSize_16sp,
                            weight: FontWeight.w500,
                          ),
                        ),
                      );
                    },
                  ),
                ),
                Flexible(
                  flex: 3,
                  child: FilterCheckList(
                    filterList: homeCtrl.filtersData[homeCtrl.selectedFilterIndex].keys.toList(),
                  )
                )
              ],
            ),
          ),
        );
      }
    );
  }
}
