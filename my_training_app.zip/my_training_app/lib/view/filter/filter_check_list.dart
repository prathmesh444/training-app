import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_training_app/controller/screen_controller/home_controller.dart';
import 'package:my_training_app/view/helper/colors/app_colors.dart';
import 'package:my_training_app/view/helper/sizing/sized_box_extension.dart';
import 'package:my_training_app/view/helper/widgets/text.dart';


class FilterCheckList extends StatefulWidget {

   const FilterCheckList({super.key, required this.filterList});

  final List<String> filterList;

  @override
  State<FilterCheckList> createState() => _FilterCheckListState();
}

class _FilterCheckListState extends State<FilterCheckList> {
  HomeController homeCtrl = Get.find();

  @override
  Widget build(BuildContext context) {
    return (homeCtrl.selectedFilterIndex > 0)
        ? ListView.builder(
              itemCount: widget.filterList.length,
              itemBuilder: (context, index) {
        return Row(
          children: [
            Checkbox(
              value: homeCtrl.filtersData[homeCtrl.selectedFilterIndex][widget.filterList[index]],
              activeColor: AppColors.primaryColor,
              onChanged: (boxChecked) {
                if(homeCtrl.isFilterUpdated == false){
                  homeCtrl.isFilterUpdated = true;
                  homeCtrl.update();
                }
                (boxChecked == true)
                   ? homeCtrl.markFilter(widget.filterList[index])
                    : homeCtrl.unmarkFilter(widget.filterList[index]);
              },
            ),
            PercentSizedBox.width(0.02),

            BuildText(text: widget.filterList[index]),

          ],
        );
              },
            ) : const SizedBox.shrink();
  }
}


