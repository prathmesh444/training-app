class Training {
  final String id;
  final String name;
  final DateTime startDate;
  final DateTime endDate;
  final double actualPrice;
  final double discountedPrice;
  final String location;
  final DateTime startTime;
  final DateTime endTime;
  final String trainerName;
  final String trainerDesignation;
  final String trainingSummary;
  final double rating;
  final int duration;
  final String category;
  final String trainingImage;
  final String trainerImage;
  final String tagLine;

  Training({
    required this.id,
    required this.name,
    required this.startDate,
    required this.endDate,
    required this.actualPrice,
    required this.discountedPrice,
    required this.location,
    required this.startTime,
    required this.endTime,
    required this.trainerName,
    required this.trainerDesignation,
    required this.trainingSummary,
    required this.rating,
    required this.duration,
    required this.category,
    required this.trainingImage,
    required this.trainerImage,
    required this.tagLine,
  });

  /// Factory method to create a Training object from JSON
  factory Training.fromJson(Map<String, dynamic> json) {
    return Training(
      id: json['id'],
      name: json['name'],
      startDate: DateTime.parse(json['startDate']),
      endDate: DateTime.parse(json['endDate']),
      actualPrice: json['actualPrice'].toDouble(),
      discountedPrice: json['discountedPrice'].toDouble(),
      location: json['location'],
      startTime: DateTime.fromMillisecondsSinceEpoch(json['startTime']),
      endTime: DateTime.fromMillisecondsSinceEpoch(json['endTime']),
      trainerName: json['trainerName'],
      trainerDesignation: json['trainerDesignation'],
      trainingSummary: json['trainingSummary'],
      rating: json['rating'].toDouble(),
      duration: json['duration'],
      category: json['category'],
      trainingImage: json['trainingImage'],
      trainerImage: json['trainerImage'],
      tagLine: json['tagLine'],
    );
  }

  /// Method to convert a Training object to JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'startDate': startDate.toIso8601String(),
      'endDate': endDate.toIso8601String(),
      'actualPrice': actualPrice,
      'discountedPrice': discountedPrice,
      'location': location,
      'startTime': startTime.millisecondsSinceEpoch,
      'endTime': endTime.millisecondsSinceEpoch,
      'trainerName': trainerName,
      'trainerDesignation': trainerDesignation,
      'trainingSummary': trainingSummary,
      'rating': rating,
      'duration': duration,
      'category': category,
      'trainingImage': trainingImage,
      'trainerImage': trainerImage,
      'tagLine': tagLine,
    };
  }
}
