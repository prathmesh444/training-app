import 'package:my_training_app/data/models/training.dart';
import 'package:my_training_app/view/helper/images/app_assets.dart';
import 'package:my_training_app/view/helper/logging/print_log.dart';

class TrainingRepo{
  static List<Training> getTrainings() {

    List<Training> trainings = [];
   try{
     /// Fetch data from API or local database or sample data
     var sampleData = [
       {
         "id": "T101",
         "name": "Full-Stack Mastery",
         "startDate": "2024-01-15",
         "endDate": "2024-01-20",
         "actualPrice": 500.0,
         "discountedPrice": 400.0,
         "location": "New York",
         "startTime": 1705309200000,
         "endTime": 1705334400000,
         "trainerName": "John Smith",
         "trainerDesignation": "Senior Software Engineer",
         "trainingSummary": "This training covers the essentials of full-stack web development, including front-end and back-end technologies, databases, and deployment strategies.",
         "rating": 4.8,
         "duration": 420,
         "category": "Web Development",
         "trainingImage": AppAssets.trainingImg1,
         "trainerImage": AppAssets.trainerImg1,
         "tagLine": "Filling Fast"
       },
       {
         "id": "T102",
         "name": "Flutter Advanced",
         "startDate": "2024-02-01",
         "endDate": "2024-02-05",
         "actualPrice": 600.0,
         "discountedPrice": 450.0,
         "location": "San Francisco",
         "startTime": 1706778000000,
         "endTime": 1706803200000,
         "trainerName": "Emily Davis",
         "trainerDesignation": "Mobile App Expert",
         "trainingSummary": "This course dives deep into Flutter, teaching you how to build visually stunning and performance-optimized mobile apps for both Android and iOS.",
         "rating": 4.9,
         "duration": 480,
         "category": "Mobile Development",
         "trainingImage": AppAssets.trainingImg2,
         "trainerImage": AppAssets.trainerImg2,
         "tagLine": "Early Bird"
       },
       {
         "id": "T103",
         "name": "Data Science Pro",
         "startDate": "2024-03-10",
         "endDate": "2024-03-20",
         "actualPrice": 800.0,
         "discountedPrice": 700.0,
         "location": "Boston",
         "startTime": 1709778000000,
         "endTime": 1710306000000,
         "trainerName": "Michael Brown",
         "trainerDesignation": "Data Scientist",
         "trainingSummary": "A comprehensive bootcamp covering data analysis, visualization, machine learning, and big data tools.",
         "rating": 4.7,
         "duration": 1200,
         "category": "Data Science",
         "trainingImage": AppAssets.trainingImg3,
         "trainerImage": AppAssets.trainerImg3,
         "tagLine": "Limited Seats"
       },
       {
         "id": "T104",
         "name": "Leadership Skills",
         "startDate": "2024-04-05",
         "endDate": "2024-04-07",
         "actualPrice": 300.0,
         "discountedPrice": 250.0,
         "location": "Chicago",
         "startTime": 1712254800000,
         "endTime": 1712427600000,
         "trainerName": "Sarah Johnson",
         "trainerDesignation": "Leadership Coach",
         "trainingSummary": "Learn essential leadership and team management skills to succeed as a modern manager.",
         "rating": 4.6,
         "duration": 360,
         "category": "Leadership",
         "trainingImage": AppAssets.trainingImg4,
         "trainerImage": AppAssets.trainerImg4,
         "tagLine": "Hot Pick"
       },
       {
         "id": "T105",
         "name": "AWS Cloud Pro",
         "startDate": "2024-05-15",
         "endDate": "2024-05-25",
         "actualPrice": 1000.0,
         "discountedPrice": 850.0,
         "location": "Seattle",
         "startTime": 1716018000000,
         "endTime": 1716658800000,
         "trainerName": "David Lee",
         "trainerDesignation": "Cloud Architect",
         "trainingSummary": "A hands-on course to master AWS cloud computing, covering services like EC2, S3, Lambda, and more.",
         "rating": 4.9,
         "duration": 1440,
         "category": "Cloud Computing",
         "trainingImage": AppAssets.trainingImg5,
         "trainerImage": AppAssets.trainerImg5,
         "tagLine": "Best Value"
       },
       {
         "id": "T106",
         "name": "AI Basics",
         "startDate": "2024-06-01",
         "endDate": "2024-06-10",
         "actualPrice": 1200.0,
         "discountedPrice": 1000.0,
         "location": "Austin",
         "startTime": 1717218000000,
         "endTime": 1717945200000,
         "trainerName": "Laura Martinez",
         "trainerDesignation": "AI Specialist",
         "trainingSummary": "Explore the fundamentals of AI and machine learning, including supervised and unsupervised learning techniques.",
         "rating": 4.8,
         "duration": 900,
         "category": "Artificial Intelligence",
         "trainingImage": AppAssets.trainingImg6,
         "trainerImage": AppAssets.trainerImg6,
         "tagLine": "Enroll Now"
       },
       {
         "id": "T107",
         "name": "Cybersecurity 101",
         "startDate": "2024-07-05",
         "endDate": "2024-07-08",
         "actualPrice": 700.0,
         "discountedPrice": 600.0,
         "location": "San Diego",
         "startTime": 1720371600000,
         "endTime": 1720614000000,
         "trainerName": "Robert Wilson",
         "trainerDesignation": "Cybersecurity Expert",
         "trainingSummary": "Learn the basics of cybersecurity, including threat management, ethical hacking, and securing networks.",
         "rating": 4.7,
         "duration": 540,
         "category": "Cybersecurity",
         "trainingImage": AppAssets.trainingImg7,
         "trainerImage": AppAssets.trainerImg7,
         "tagLine": "Popular Choice"
       },
       {
         "id": "T108",
         "name": "UI/UX Mastery",
         "startDate": "2024-08-01",
         "endDate": "2024-08-05",
         "actualPrice": 500.0,
         "discountedPrice": 450.0,
         "location": "Miami",
         "startTime": 1722531600000,
         "endTime": 1722790800000,
         "trainerName": "Emma Taylor",
         "trainerDesignation": "UI/UX Designer",
         "trainingSummary": "Master UI/UX design principles and tools like Figma, Sketch, and Adobe XD for creating user-friendly designs.",
         "rating": 4.8,
         "duration": 720,
         "category": "Design",
         "trainingImage": AppAssets.trainingImg2,
         "trainerImage": AppAssets.trainerImg8,
         "tagLine": "Design Lovers"
       },
       {
         "id": "T109",
         "name": "Agile Guide",
         "startDate": "2024-09-10",
         "endDate": "2024-09-12",
         "actualPrice": 400.0,
         "discountedPrice": 350.0,
         "location": "Denver",
         "startTime": 1725999600000,
         "endTime": 1726167600000,
         "trainerName": "Chris Moore",
         "trainerDesignation": "Agile Coach",
         "trainingSummary": "Understand the principles of Agile and Scrum, and how to implement them effectively in real-world projects.",
         "rating": 4.6,
         "duration": 360,
         "category": "Project Management",
         "trainingImage": AppAssets.trainingImg3,
         "trainerImage": AppAssets.trainerImg9,
         "tagLine": "Must Attend"
       },
       {
         "id": "T110",
         "name": "Marketing Growth",
         "startDate": "2024-10-01",
         "endDate": "2024-10-03",
         "actualPrice": 500.0,
         "discountedPrice": 450.0,
         "location": "Los Angeles",
         "startTime": 1727814000000,
         "endTime": 1727986800000,
         "trainerName": "Sophia Thomas",
         "trainerDesignation": "Digital Marketing Specialist",
         "trainingSummary": "Learn effective digital marketing strategies, including SEO, PPC, social media, and email marketing for business growth.",
         "rating": 4.7,
         "duration": 480,
         "category": "Marketing",
         "trainingImage": AppAssets.trainingImg5,
         "trainerImage": AppAssets.trainerImg10,
         "tagLine": "Trending"
       }
     ];

     /// Convert JSON data to Training objects
     trainings = sampleData.map((json) => Training.fromJson(json)).toList();

     PrintLog.printLog("Trainings fetched successfully, total training is ${trainings.length}");
   }
   catch(e) {
     PrintLog.printLog("Error in getTrainings: $e");
   }

   return trainings;
  }
}